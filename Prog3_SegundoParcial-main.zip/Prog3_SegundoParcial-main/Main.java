import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.;

public class Main extends Application {

    private ObservableList<Prestamos> listaPrestamos = FXCollections.observableArrayList();
    private ComboBox<String> comboTipo;
    private TableView<Prestamos> tabla;

    @Override
    public void start(Stage stage) {

        TextField txtNombre = new TextField();
        txtNombre.setPromptText("Nombre completo");

        comboTipo = new ComboBox<>();
        comboTipo.getItems().addAll("Tipos de equipos");

        Button btnLaptops = new Button("Laptops");
        Button btnProyector = new Button("Proyector");
        Button btnTablet = new Button("Tablet");
        Button btnCableHDMI = new Button("Cable HDMI");

        tabla = new TableView<>();

        TableColumn<Prestamos, String> colNombre = new TableColumn<>("Nombre");
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));

        TableColumn<Prestamos, String> colTipo = new TableColumn<>("TiposdeEquipos");
        colTipo.setCellValueFactory(new PropertyValueFactory<>("tiposdeEquipos"));

        tabla.getColumns().addAll(colNombre, colTipo);
        tabla.setItems(listaPrestamos);

        btnLaptos.setOnAction(e -> {
            String nombre = txtNombre.getText();
            String tipo = comboTipo.getValue();

            if (nombre.isEmpty() || tipo == null) {
                mostrarAlerta("Error", "Debe completar todos los pasos");
                return;
            }

            listaPrestamos.add(new Prestamos(nombre, tipo));
            txtNombre.clear();
        });

        btnProyector.setOnAction(e -> {
            Prestamos seleccionado = tabla.getSelectionModel().getSelectedItem();

            if (seleccionado == null) {
                mostrarAlerta("Advertencia", "Seleccione un equipo");
                return;
            }

            listaPrestamos.remove(seleccionado);
        });

        btnTablet.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setHeaderText("Nuevo tipo de prestamos");

            dialog.showAndWait().ifPresent(tipo -> {
                if (tipo.isEmpty() || comboTipo.getItems().contains(tipo)) {
                    mostrarAlerta("Error", "Tipo inválido o repetido");
                } else {
                    comboTipo.getItems().add(tipo);
                }
            });
        });

        btnCableHDMI.setOnAction(e -> {
            btnCableHDMI.setDisable(true);

            new Thread(() -> {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("prestamos.txt"))) {
                    for (Prestamos  : listaPrestamos) {
                        writer.write(v.getNombre() + "," + v.getTipo());
                        writer.newLine();
                    }

                    Platform.runLater(() -> {
                        mostrarAlerta("Éxito", "Datos guardados correctamente");
                        btnCableHDMI.setDisable(false);
                    });

                } catch (IOException ex) {
                    Platform.runLater(() -> {
                        mostrarAlerta("Error", "Error al guardar");
                        btnCableHDMI.setDisable(false);
                    });
                }
            }).start();
        });

        VBox root = new VBox(10, txtNombre, comboTipo, btnLaptops, btnProyector, btnTablet, btnCableHDMI, tabla);
        root.setPadding(new Insets(10));

        stage.setScene(new Scene(root, 400, 500));
        stage.setTitle("Registro de prestamos");
        stage.show();

        cargarDatos();
    }

    private void cargarDatos() {
        File archivo = new File("prestamos.txt");

        if (!archivo.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
            String linea;

            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(",");
                listaPrestamos.add(new Prestamos(partes[0], partes[1]));
            }

        } catch (IOException e) {
            mostrarAlerta("Error", "Error al cargar datos");
        }
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch();
    }
}
